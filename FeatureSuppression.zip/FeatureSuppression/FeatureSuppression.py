#Author-
#Description-

import adsk.core, adsk.fusion

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface

        # Access the active design
        design = app.activeProduct
        comp = design.allComponents.itemByName('Drive Body')

        # Get the desired design parameters
        parameter1 = design.allParameters.itemByName('suppressFiber')

        # Retrieve the desired features
        feature1 = comp.features.itemByName('Fiber Holes')
        feature2 = comp.features.itemByName('Bottom Fiber Holes 1')
        feature3 = comp.features.itemByName('Bottom Fiber Holes 2')


        # Define a function to modify feature suppression state
        def modifyFeatureSuppression():
            if parameter1.value > 0:
                feature1.isSuppressed = True
                feature2.isSuppressed = True
                feature3.isSuppressed = True
            else:
                feature1.isSuppressed = False
                feature2.isSuppressed = False
                feature3.isSuppressed = False
                
        # Initial modification of feature suppression
        modifyFeatureSuppression()

    except Exception as e:
        if ui:
            ui.messageBox('Script execution failed: {}'.format(str(e)))